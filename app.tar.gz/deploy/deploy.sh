#!/usr/bin/env bash
# TradingBible — VPS deploy (monorepo structure).
# Expects: /var/www/tradingbible/apps/web/ and /var/www/tradingbible/apps/api/
set -euo pipefail

APP_DIR="/var/www/tradingbible"
API_DIR="$APP_DIR/apps/api"
WEB_DIR="$APP_DIR/apps/web"
WEB_DIST="$WEB_DIR/dist"
DOMAIN="tradingbible.app"
REPO_URL="https://github.com/malibaequityholdingsltd/TradingBible"

echo "==> 1/10 System packages"
apt-get update -y
apt-get install -y nginx git curl openssl
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
npm install -g pm2

echo "==> 2/10 Remove any local PocketBase service"
systemctl stop pocketbase 2>/dev/null || true
systemctl disable pocketbase 2>/dev/null || true
rm -f /etc/systemd/system/pocketbase.service
systemctl daemon-reload || true

echo "==> 3/10 Clone / update source (correct monorepo structure)"
if [ -d "$APP_DIR/.git" ]; then
  echo "  Repo exists — pulling latest"
  git -C "$APP_DIR" pull --ff-only
else
  echo "  Fresh clone into $APP_DIR"
  rm -rf "$APP_DIR"
  git clone "$REPO_URL" "$APP_DIR"
fi

# Verify monorepo structure
echo "  Verifying structure..."
test -f "$APP_DIR/package.json"   || { echo "ERROR: root package.json missing"; exit 1; }
test -d "$WEB_DIR"                || { echo "ERROR: apps/web/ missing"; exit 1; }
test -f "$WEB_DIR/package.json"   || { echo "ERROR: apps/web/package.json missing"; exit 1; }
test -f "$WEB_DIR/vite.config.js" || { echo "ERROR: apps/web/vite.config.js missing"; exit 1; }
test -d "$API_DIR"                || { echo "ERROR: apps/api/ missing"; exit 1; }
test -f "$API_DIR/package.json"   || { echo "ERROR: apps/api/package.json missing"; exit 1; }
test -f "$API_DIR/src/main.js"    || test -f "$API_DIR/src/index.js" || { echo "ERROR: apps/api/src/main.js or index.js missing"; exit 1; }
echo "  Structure OK"
ls -la "$APP_DIR/apps/"

echo "==> 4/10 Install dependencies"
cd "$APP_DIR"
# Root (hoists shared deps for workspaces)
npm install
# Web workspace
echo "  Installing apps/web deps..."
npm install --workspace apps/web
# API workspace
echo "  Installing apps/api deps..."
npm install --workspace apps/api

echo "==> 5/10 API environment"
if [ ! -f "$API_DIR/.env" ]; then
  cat > "$API_DIR/.env" <<'ENVEOF'
NODE_ENV=production
PORT=3001
CORS_ORIGIN=https://tradingbible.app
DATABASE_URL=
POCKETBASE_URL=
ALPHA_VANTAGE_API_KEY=
FINNHUB_API_KEY=
ENVEOF
  echo "  Created $API_DIR/.env — fill in cloud database URL + API keys"
fi

echo "==> 6/10 Build web app"
cd "$WEB_DIR"
npm run build
test -f "$WEB_DIST/index.html" || { echo "BUILD FAILED: index.html missing in dist/"; exit 1; }
echo "  Build OK: $(ls $WEB_DIST | wc -l) files in dist/"

echo "==> 7/10 SSL + Nginx"
if [ ! -f /etc/ssl/certs/tradingbible.crt ]; then
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/tradingbible.key \
    -out /etc/ssl/certs/tradingbible.crt \
    -subj "/CN=$DOMAIN"
fi
# Write Nginx config pointing at the correct dist path
cat > /etc/nginx/sites-available/$DOMAIN <<NGINXEOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN www.$DOMAIN;

    ssl_certificate     /etc/ssl/certs/tradingbible.crt;
    ssl_certificate_key /etc/ssl/private/tradingbible.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    root $WEB_DIST;
    index index.html;

    location / {
        try_files \$uri \$uri/ /index.html;
        expires 1h;
        add_header Cache-Control "public, must-revalidate";
    }

    location ~* \.(js|css|woff2?|ttf|svg|png|jpg|webp|ico)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location /api/ {
        proxy_pass         http://127.0.0.1:3001/;
        proxy_http_version 1.1;
        proxy_set_header   Host \$host;
        proxy_set_header   X-Real-IP \$remote_addr;
        proxy_set_header   X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }

    location /hcgi/api/ {
        proxy_pass         http://127.0.0.1:3001/;
        proxy_http_version 1.1;
        proxy_set_header   Host \$host;
        proxy_set_header   X-Real-IP \$remote_addr;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;
}
NGINXEOF
ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/$DOMAIN
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

echo "==> 8/10 Detect API entry point"
if [ -f "$API_DIR/src/main.js" ]; then
  API_ENTRY="$API_DIR/src/main.js"
else
  API_ENTRY="$API_DIR/src/index.js"
fi
echo "  Using entry: $API_ENTRY"

echo "==> 9/10 Start API via PM2"
pm2 delete tradingbible-api 2>/dev/null || true
pm2 start "$API_ENTRY" \
  --name "tradingbible-api" \
  --env production \
  --cwd "$API_DIR"
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null || true

echo "==> 10/10 Verification"
sleep 4
pm2 status
echo -n "  API /health     : "; curl -fsS http://127.0.0.1:3001/health && echo " OK" || echo " FAIL"
echo -n "  HTTP redirect   : "; curl -sI http://127.0.0.1/ | head -1
echo -n "  HTTPS SPA       : "; curl -fskS https://127.0.0.1/ -o /dev/null && echo "OK" || echo "FAIL"
echo -n "  API quotes      : "; curl -fskS "https://127.0.0.1/api/quotes?symbol=BTCUSD" | head -c 200; echo

echo ""
echo "=== Deployment complete — https://$DOMAIN ==="
