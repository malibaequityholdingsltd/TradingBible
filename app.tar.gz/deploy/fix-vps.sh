#!/usr/bin/env bash
# TradingBible — repair/restart VPS services (monorepo structure).
set -uo pipefail

APP_DIR="/var/www/tradingbible"
API_DIR="$APP_DIR/apps/api"
WEB_DIR="$APP_DIR/apps/web"
WEB_DIST="$WEB_DIR/dist"
DOMAIN="tradingbible.app"
REPO_URL="https://github.com/malibaequityholdingsltd/TradingBible"

echo "=== 1. Purge local PocketBase ==="
systemctl stop pocketbase 2>/dev/null || true
systemctl disable pocketbase 2>/dev/null || true
rm -f /etc/systemd/system/pocketbase.service
systemctl daemon-reload || true
pkill -f pocketbase 2>/dev/null || true
echo "PocketBase service removed."

echo "=== 2. Verify / fix monorepo structure ==="
NEEDS_CLONE=0
[ -d "$APP_DIR/.git" ]            || NEEDS_CLONE=1
[ -d "$WEB_DIR" ]                 || NEEDS_CLONE=1
[ -f "$WEB_DIR/vite.config.js" ]  || NEEDS_CLONE=1
[ -d "$API_DIR" ]                 || NEEDS_CLONE=1

if [ "$NEEDS_CLONE" = "1" ]; then
  echo "  Structure broken — recloning from $REPO_URL"
  rm -rf "$APP_DIR"
  git clone "$REPO_URL" "$APP_DIR"
else
  echo "  Structure OK — pulling latest"
  git -C "$APP_DIR" pull --ff-only || true
fi

echo "  Directory listing:"
ls -la "$APP_DIR/apps/" 2>/dev/null || echo "  apps/ not found"
ls -la "$WEB_DIR/"      2>/dev/null | head -8 || echo "  apps/web/ not found"
ls -la "$API_DIR/"      2>/dev/null | head -8 || echo "  apps/api/ not found"

echo "=== 3. Install dependencies ==="
cd "$APP_DIR"
npm install
npm install --workspace apps/web
npm install --workspace apps/api

echo "=== 4. API .env ==="
if [ ! -f "$API_DIR/.env" ]; then
  printf 'NODE_ENV=production\nPORT=3001\nCORS_ORIGIN=https://%s\nDATABASE_URL=\nPOCKETBASE_URL=\nALPHA_VANTAGE_API_KEY=\nFINNHUB_API_KEY=\n' "$DOMAIN" > "$API_DIR/.env"
  echo "  Created $API_DIR/.env — add cloud database URL and API keys."
fi

echo "=== 5. Build web app ==="
if [ ! -f "$WEB_DIST/index.html" ]; then
  echo "  dist missing — rebuilding"
  cd "$WEB_DIR"
  npm run build
fi
echo "  dist files: $(ls $WEB_DIST 2>/dev/null | wc -l)"

echo "=== 6. Nginx ==="
# Update root to match actual dist path
sed -i "s|root .*;|root $WEB_DIST;|" /etc/nginx/sites-available/$DOMAIN 2>/dev/null || true
# Also rewrite proxy port if needed (old configs used 3000)
sed -i "s|proxy_pass.*127.0.0.1:3000|proxy_pass http://127.0.0.1:3001|g" /etc/nginx/sites-available/$DOMAIN 2>/dev/null || true
nginx -t && systemctl restart nginx && echo "  Nginx OK"

echo "=== 7. API via PM2 ==="
if [ -f "$API_DIR/src/main.js" ]; then
  API_ENTRY="$API_DIR/src/main.js"
else
  API_ENTRY="$API_DIR/src/index.js"
fi
pm2 delete tradingbible-api 2>/dev/null || true
pm2 start "$API_ENTRY" --name "tradingbible-api" --env production --cwd "$API_DIR"
pm2 save

echo "=== 8. Health checks ==="
sleep 4
pm2 status
echo -n "API  /health     : "; curl -fsS http://127.0.0.1:3001/health && echo " OK" || echo " FAIL"
echo -n "HTTP redirect    : "; curl -sI http://127.0.0.1/ | head -1
echo -n "HTTPS SPA        : "; curl -sko /dev/null -w '%{http_code}\n' https://127.0.0.1/
echo -n "HTTPS API quotes : "; curl -sko /dev/null -w '%{http_code}\n' "https://127.0.0.1/api/quotes?symbol=BTCUSD"

echo "=== 9. Recent logs ==="
tail -n 10 /var/log/nginx/error.log 2>/dev/null || true
pm2 logs tradingbible-api --lines 15 --nostream 2>/dev/null || true
echo "Done."
