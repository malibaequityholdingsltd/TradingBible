import { Router } from 'express';
import healthCheck from './health-check.js';
import integratedAiRouter from './integrated-ai.js';
import marketData from './market-data.js';
import quotes from './quotes.js';
import candles from './candles.js';
import indicator from './indicator.js';
import heatmap from './heatmap.js';
import economicCalendar from './economic-calendar.js';
import { intraday, daily, weekly, monthly } from './market-series.js';
import paddleRouter from './paddle.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/integrated-ai', integratedAiRouter);
    router.get('/market-data', marketData);
    router.get('/quotes', quotes);
    router.get('/candles', candles);
    router.get('/indicator', indicator);
    router.get('/heatmap', heatmap);
    router.get('/economic-calendar', economicCalendar);
    router.get('/intraday', intraday);
    router.get('/daily', daily);
    router.get('/weekly', weekly);
    router.get('/monthly', monthly);
    router.use('/paddle', paddleRouter);

    return router;
};
