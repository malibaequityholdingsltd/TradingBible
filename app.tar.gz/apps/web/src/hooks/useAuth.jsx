import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(pb.authStore.record);

  useEffect(() => {
    const unsub = pb.authStore.onChange((_t, record) => setUser(record));
    return unsub;
  }, []);

  const login = useCallback((email, password) =>
    pb.collection('users').authWithPassword(email, password), []);

  const signup = useCallback(async ({ email, password, username }) => {
    await pb.collection('users').create({
      email,
      password,
      passwordConfirm: password,
      username: username || email.split('@')[0],
      name: username || email.split('@')[0],
      plan: 'trial',
    });
    return pb.collection('users').authWithPassword(email, password);
  }, []);

  // Request an emailed OTP as the second factor during MFA.
  const requestOTP = useCallback((email) =>
    pb.collection('users').requestOTP(email), []);

  // Complete MFA login with the emailed code + the mfaId from step one.
  const loginWithOTP = useCallback((otpId, code, mfaId) =>
    pb.collection('users').authWithOTP(otpId, code, { mfaId }), []);

  // Passwordless login: authenticate with the emailed code alone.
  const loginWithCode = useCallback((otpId, code) =>
    pb.collection('users').authWithOTP(otpId, code), []);

  const requestReset = useCallback((email) =>
    pb.collection('users').requestPasswordReset(email), []);

  const updateProfile = useCallback(async (data) => {
    if (!pb.authStore.record) throw new Error('Not authenticated');
    const rec = await pb.collection('users').update(pb.authStore.record.id, data);
    setUser({ ...rec });
    return rec;
  }, []);

  const logout = useCallback(() => pb.authStore.clear(), []);

  return (
    <AuthContext.Provider value={{
      user, isAuthed: pb.authStore.isValid, login, signup, requestOTP, loginWithOTP, loginWithCode, requestReset, updateProfile, logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
