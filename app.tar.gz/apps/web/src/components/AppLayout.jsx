import React, { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Bot, Plug, Crown, User, LogOut, Menu, BarChart3, FileText, Calculator, Users, GraduationCap, Lock, Code2, Palette, CreditCard, HelpCircle, CandlestickChart, Grid2x2, Gauge, Star, Bell, Radar, CalendarClock, Landmark, ListOrdered } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { avatarUrl } from '@/lib/avatar';
import { useNotifications } from '@/hooks/useNotifications';
import OnboardingTutorial from '@/components/OnboardingTutorial';
import LiveChatWidget from '@/components/LiveChatWidget';

const NAV_GROUPS = [
  {
    label: 'Trade',
    items: [
      { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
      { to: '/app/analytics', label: 'Analytics', icon: BarChart3 },
      { to: '/app/charts', label: 'Advanced Charts', icon: CandlestickChart },
      { to: '/app/indicators', label: 'Indicators', icon: Gauge },
      { to: '/app/heatmaps', label: 'Heatmaps', icon: Grid2x2 },
      { to: '/app/watchlists', label: 'Watchlists', icon: Star },
      { to: '/app/terminal', label: 'Terminal', icon: ListOrdered },
      { to: '/app/signals', label: 'Trading Signals', icon: Radar },
      { to: '/app/alerts', label: 'Price Alerts', icon: Bell },
      { to: '/app/economic-calendar', label: 'Economic Calendar', icon: CalendarClock },
      { to: '/app/journal', label: 'Trading Journal', icon: BookOpen },
      { to: '/app/reports', label: 'Reports', icon: FileText },
      { to: '/app/coach', label: 'AI Coach', icon: Bot },
      { to: '/app/tools', label: 'Risk Tools', icon: Calculator },
      { to: '/app/brokers', label: 'Brokers', icon: Plug },
      { to: '/app/wallet', label: 'Wallet', icon: Landmark },
    ],
  },
  {
    label: 'Learn & Connect',
    items: [
      { to: '/app/community', label: 'Community', icon: Users },
      { to: '/app/academy', label: 'Academy', icon: GraduationCap },
      { to: '/app/api-docs', label: 'API Docs', icon: Code2 },
      { to: '/app/integrations', label: 'API & Integrations', icon: Plug },
    ],
  },
  {
    label: 'Account',
    items: [
      { to: '/app/profile', label: 'Profile', icon: User },
      { to: '/app/billing', label: 'Billing', icon: CreditCard },
      { to: '/app/security', label: 'Security', icon: Lock },
      { to: '/app/branding', label: 'White-label', icon: Palette },
    ],
  },
];

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <img src="https://horizons-cdn.hostinger.com/31a01204-0f8d-4aa3-a78b-78fb8b946e53/f18f53c1fa5ec4181c7033589080fd00.png" alt="TradingBible logo" className="h-9 w-9 rounded-lg object-contain" />
      <div className="leading-tight">
        <div className="font-semibold tracking-tight text-[#f0ecdd]">Trading<span className="gold-text">Bible</span></div>
        <div className="text-[10px] uppercase tracking-[0.2em] text-[#8a8577]">Terminal</div>
      </div>
    </div>
  );
}

export default function AppLayout({ children, title, trialDays = 7 }) {
  const [open, setOpen] = useState(false);
  const [tutorial, setTutorial] = useState(false);
  const nav = useNavigate();
  const { user, logout, updateProfile } = useAuth();
  const { unseen } = useNotifications();
  const initial = (user?.username || user?.email || 'A').charAt(0).toUpperCase();
  const signOut = () => { logout(); nav('/'); };

  const isAdmin = user?.role === 'admin';
  const avatar = avatarUrl(user);

  useEffect(() => {
    if (user && user.tutorialDone === false) setTutorial(true);
  }, [user]);

  const completeTutorial = () => { updateProfile({ tutorialDone: true }).catch(() => {}); };

  const SideContent = (
    <div className="flex h-full flex-col">
      <div className="px-5 py-6"><Brand /></div>
      <nav className="flex-1 space-y-4 overflow-y-auto px-3 pb-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.label} className="space-y-1">
            <div className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#5f5b50]">{group.label}</div>
            {group.items.filter((it) => !it.adminOnly || isAdmin).map(({ to, label, icon: Icon, end }) => (
              <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
                className={({ isActive }) => `flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${isActive ? 'bg-[#d4af37]/12 text-[#f0ecdd] gold-glow' : 'text-[#8a8577] hover:bg-white/5 hover:text-[#e9e7df]'}`}>
                <Icon className="h-[18px] w-[18px]" strokeWidth={1.9} />{label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
      <div className="m-3 rounded-xl glass p-4">
        <div className="flex items-center gap-2 text-[#d4af37]"><Crown className="h-4 w-4" /><span className="text-xs font-semibold">Premium Trial</span></div>
        <p className="mt-1 text-xs text-[#8a8577]">{trialDays} days of full access remaining.</p>
        <button onClick={() => nav('/app/billing')} className="mt-3 w-full rounded-lg bg-gradient-to-r from-[#f4e6a8] to-[#c99a25] py-2 text-xs font-semibold text-[#0a0a0f] transition hover:opacity-90">Upgrade Plan</button>
      </div>
      <div className="border-t border-[#d4af37]/12 px-3 py-3">
        <button onClick={signOut} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-[#8a8577] transition hover:bg-white/5 hover:text-[#e9e7df]"><LogOut className="h-[18px] w-[18px]" strokeWidth={1.9} />Sign out</button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-transparent pt-[var(--header-h)]">
      <aside className="fixed left-0 top-[var(--header-h)] bottom-0 z-30 hidden w-64 border-r border-[#d4af37]/12 bg-[#0a0a0f] lg:block">{SideContent}</aside>
      {open && <div className="fixed inset-x-0 top-[var(--header-h)] bottom-0 z-40 bg-black/70 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed left-0 top-[var(--header-h)] bottom-0 z-40 w-64 border-r border-[#d4af37]/12 bg-[#0a0a0f] transition-transform lg:hidden ${open ? 'translate-x-0' : '-translate-x-full'}`}>{SideContent}</aside>

      <div className="lg:pl-64">
        <header className="sticky top-[var(--header-h)] z-20 flex items-center justify-between border-b border-[#d4af37]/12 bg-[#07070a]/80 px-4 py-3.5 backdrop-blur sm:px-5 sm:py-4">
          <div className="flex items-center gap-3">
            <button className="lg:hidden" onClick={() => setOpen(true)}><Menu className="h-6 w-6 text-[#d4af37]" /></button>
            <h1 className="text-base font-semibold text-[#f0ecdd] sm:text-xl">{title}</h1>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <button onClick={() => nav('/app/alerts')} className="relative grid h-9 w-9 place-items-center rounded-full border border-[#d4af37]/25 text-[#d4af37] transition hover:border-[#d4af37]/60" title="Alerts & notifications">
              <Bell className="h-4 w-4" />
              {unseen > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">{unseen > 9 ? '9+' : unseen}</span>}
            </button>
            <button onClick={() => setTutorial(true)} className="flex items-center gap-1.5 rounded-full border border-[#d4af37]/25 px-3 py-1 text-xs text-[#d4af37] transition hover:border-[#d4af37]/60"><HelpCircle className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Need Help?</span></button>
            <button onClick={() => nav('/app/profile')} className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-[#f4e6a8] to-[#a67c1e] text-sm font-bold text-[#0a0a0f]">{avatar ? <img src={avatar} alt="avatar" className="h-full w-full object-cover" /> : initial}</button>
          </div>
        </header>
        <main className="p-4 sm:p-5 lg:p-7">
          {children}
        </main>
      </div>
      {tutorial && <OnboardingTutorial onClose={() => setTutorial(false)} onComplete={completeTutorial} />}
      <LiveChatWidget />
    </div>
  );
}
