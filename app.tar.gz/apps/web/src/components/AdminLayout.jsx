import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, Settings, FileText, CreditCard, LibraryBig, BarChart3,
  LogOut, Menu, Shield, X, ChevronRight, Bell, Search, Moon, Sun, Plug, Key, Package
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';

const NAV = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'User Management', icon: Users },
  { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/admin/billing', label: 'Billing & Revenue', icon: CreditCard },
  { to: '/admin/content', label: 'Content', icon: LibraryBig },
  { to: '/admin/reports', label: 'Reports & Logs', icon: FileText },
  { divider: true },
  { to: '/admin/integrations', label: 'Integrations', icon: Plug },
  { to: '/admin/api-keys', label: 'API Keys', icon: Key },
  { to: '/admin/plugins', label: 'Plugins', icon: Package },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
];

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative grid h-9 w-9 place-items-center rounded-lg overflow-hidden">
        <img src="/icons/icon-192.png" alt="TradingBible" className="h-full w-full object-cover" onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling.style.display = 'flex'; }} />
        <div className="hidden absolute inset-0 grid place-items-center bg-[#d4af37]/15 text-[#d4af37]">
          <Shield className="h-5 w-5" />
        </div>
      </div>
      <div className="leading-tight">
        <div className="font-semibold tracking-tight text-[#f0ecdd]">Trading<span className="gold-text">Bible</span></div>
        <div className="text-[10px] uppercase tracking-[0.2em] text-[#d4af37]">Admin Console</div>
      </div>
    </div>
  );
}

export default function AdminLayout({ children, title }) {
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme() || {};
  const initial = (user?.username || user?.email || 'A').charAt(0).toUpperCase();
  const signOut = () => { logout(); nav('/'); };

  const SideContent = (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-[#d4af37]/10">
        <Brand />
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-4">
        {NAV.map((item, idx) => {
          if (item.divider) return <div key={`div-${idx}`} className="my-2 h-px bg-[#d4af37]/10" />;
          const { to, label, icon: Icon, end } = item;
          return (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${
                  isActive
                    ? 'bg-[#d4af37]/12 text-[#f0ecdd] shadow-sm'
                    : 'text-[#8a8577] hover:bg-white/5 hover:text-[#e9e7df]'
                }`
              }>
              {({ isActive }) => (
                <>
                  <Icon className={`h-[18px] w-[18px] shrink-0 transition-colors ${isActive ? 'text-[#d4af37]' : 'text-[#6a665a] group-hover:text-[#8a8577]'}`} strokeWidth={1.9} />
                  <span className="flex-1 truncate">{label}</span>
                  {isActive && <ChevronRight className="h-3.5 w-3.5 text-[#d4af37]/60 shrink-0" />}
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* User footer */}
      <div className="border-t border-[#d4af37]/10 px-3 py-3 space-y-1">
        {setTheme && (
          <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-[#8a8577] hover:bg-white/5 hover:text-[#e9e7df]">
            {theme === 'light' ? <Moon className="h-[18px] w-[18px]" strokeWidth={1.9} /> : <Sun className="h-[18px] w-[18px]" strokeWidth={1.9} />}
            {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
          </button>
        )}
        <button onClick={signOut} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-[#8a8577] hover:bg-red-500/8 hover:text-red-400 transition-colors">
          <LogOut className="h-[18px] w-[18px]" strokeWidth={1.9} />Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-60 shrink-0 flex-col glass border-r border-[#d4af37]/10 fixed inset-y-0 left-0 z-30">
        {SideContent}
      </aside>

      {/* Mobile overlay */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 glass border-r border-[#d4af37]/10">
            <button onClick={() => setOpen(false)} className="absolute right-3 top-3 rounded-lg p-1.5 text-[#8a8577] hover:bg-white/8">
              <X className="h-5 w-5" />
            </button>
            {SideContent}
          </aside>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 lg:ml-60 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-[#d4af37]/10 bg-[#07070a]/80 px-4 backdrop-blur-sm lg:px-6">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(true)} className="lg:hidden rounded-lg p-1.5 text-[#8a8577] hover:bg-white/8">
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <span className="text-xs uppercase tracking-wider text-[#6a665a]">Admin</span>
              <span className="mx-2 text-[#3a3a3a]">/</span>
              <span className="text-sm font-medium text-[#e9e7df]">{title}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/app" className="hidden sm:flex items-center gap-1.5 rounded-lg border border-[#d4af37]/15 px-3 py-1.5 text-xs text-[#8a8577] hover:border-[#d4af37]/30 hover:text-[#c9c4b4]">
              View App
            </NavLink>
            <div className="flex items-center gap-2 rounded-xl border border-[#d4af37]/15 bg-[#0f0f14]/60 px-2.5 py-1.5">
              <div className="grid h-6 w-6 place-items-center rounded-full bg-[#d4af37]/15 text-xs font-bold text-[#d4af37]">{initial}</div>
              <div className="hidden sm:block">
                <div className="text-xs font-medium text-[#e9e7df]">{user?.username || 'Admin'}</div>
                <div className="text-[10px] text-[#6a665a]">Administrator</div>
              </div>
              <Shield className="h-3.5 w-3.5 text-[#d4af37]/60" />
            </div>
          </div>
        </header>

        {/* Page content */}
        <div className="flex-1 p-4 lg:p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
