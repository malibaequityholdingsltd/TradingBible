import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, Check, User } from 'lucide-react';
import { MARKETS, EXPERIENCE, GOALS } from '@/lib/mockData';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

const LOGO = 'https://horizons-cdn.hostinger.com/31a01204-0f8d-4aa3-a78b-78fb8b946e53/f18f53c1fa5ec4181c7033589080fd00.png';

function Shell({ children }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center bg-[#07070a] px-4 pt-[calc(6rem+var(--safe-top))] pb-10 sm:px-5 sm:pt-[calc(7rem+var(--safe-top))] sm:pb-12">
      <div className="absolute inset-0 grain opacity-30" />
      <div className="relative w-full max-w-md">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2.5 sm:mb-8">
          <img src={LOGO} alt="TradingBible logo" className="h-11 w-11 rounded-lg object-contain gold-glow" />
          <span className="text-lg font-semibold">Trading<span className="gold-text">Bible</span></span>
        </Link>
        {children}
      </div>
    </div>
  );
}

const Field = ({ icon: Icon, ...p }) => (
  <div className="flex min-h-[48px] items-center gap-3 rounded-xl border border-[#d4af37]/15 bg-[#0f0f14] px-4 py-3 focus-within:border-[#d4af37]/50">
    <Icon className="h-4 w-4 shrink-0 text-[#8a8577]" />
    <input {...p} className="w-full bg-transparent text-sm text-[#e9e7df] placeholder-[#6a665a] outline-none" />
  </div>
);

const goldBtn = 'flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#f4e6a8] to-[#c99a25] py-3 font-semibold text-[#0a0a0f] transition hover:opacity-90 disabled:opacity-60';

// Route the user to the correct portal based on role after auth.
function destForUser(rec) {
  return rec?.role === 'admin' ? '/admin' : '/app';
}

export function LoginPage() {
  const nav = useNavigate();
  const { login } = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const auth = await login(email.trim(), password);
      nav(destForUser(auth?.record));
    } catch (err) {
      toast({ variant: 'destructive', title: 'Login failed', description: err?.status === 400 ? 'Incorrect email or password.' : 'Unable to sign in. Please try again.' });
    } finally { setBusy(false); }
  };

  return (
    <Shell>
      <div className="glass rounded-2xl p-6 sm:p-7">
        <h1 className="text-center text-2xl font-bold">Welcome back</h1>
        <p className="mt-1 text-center text-sm text-[#8a8577]">Sign in with your email and password.</p>
        <form className="mt-5 space-y-3" onSubmit={submit}>
          <Field icon={Mail} type="email" placeholder="you@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
          <Field icon={Lock} type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="current-password" />
          <button disabled={busy} className={goldBtn}>{busy ? 'Signing in…' : 'Sign in'} <ArrowRight className="h-4 w-4" /></button>
        </form>
        <div className="mt-4 text-center text-xs"><Link to="/reset" className="text-[#8a8577] hover:text-[#d4af37]">Forgot your password?</Link></div>
        <p className="mt-6 text-center text-sm text-[#8a8577]">New to TradingBible? <Link to="/signup" className="text-[#d4af37] hover:underline">Create an account</Link></p>
      </div>
    </Shell>
  );
}

export function SignupPage() {
  const nav = useNavigate();
  const { signup } = useAuth();
  const { toast } = useToast();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (password.length < 8) return toast({ variant: 'destructive', title: 'Weak password', description: 'Use at least 8 characters.' });
    setBusy(true);
    try {
      await signup({ email: email.trim(), password, username: username.trim() });
      nav('/onboarding');
    } catch (err) {
      toast({ variant: 'destructive', title: 'Could not create account', description: err?.status === 400 ? 'That email may already be registered.' : 'Please try again.' });
    } finally { setBusy(false); }
  };

  return (
    <Shell>
      <div className="mb-4 flex justify-center">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-[#d4af37]/30 px-2.5 py-0.5 text-[11px] text-[#d4af37]"><Check className="h-3 w-3" /> 7-day Premium Trial · No card required</span>
      </div>
      <div className="glass rounded-2xl p-6 sm:p-7">
        <h1 className="text-center text-2xl font-bold">Create your account</h1>
        <p className="mt-1 text-center text-sm text-[#8a8577]">Sign up with your email and a password.</p>
        <form className="mt-5 space-y-3" onSubmit={submit}>
          <Field icon={User} type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
          <Field icon={Mail} type="email" placeholder="you@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
          <Field icon={Lock} type="password" placeholder="Password (min 8 characters)" value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="new-password" />
          <button disabled={busy} className={goldBtn}>{busy ? 'Creating…' : 'Create account'} <ArrowRight className="h-4 w-4" /></button>
        </form>
        <p className="mt-6 text-center text-sm text-[#8a8577]">Already have an account? <Link to="/login" className="text-[#d4af37] hover:underline">Log in</Link></p>
      </div>
    </Shell>
  );
}

export function ResetPage() {
  const { requestReset } = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await requestReset(email.trim());
      setSent(true);
      toast({ title: 'Reset link sent', description: 'Check your inbox for a password reset link.' });
    } catch {
      toast({ variant: 'destructive', title: 'Could not send reset link', description: 'Please check your email and try again.' });
    } finally { setBusy(false); }
  };

  return (
    <Shell>
      <div className="glass rounded-2xl p-6 sm:p-7">
        <h1 className="text-center text-2xl font-bold">Reset your password</h1>
        <p className="mt-1 text-center text-sm text-[#8a8577]">Enter your email and we'll send you a reset link.</p>
        {sent ? (
          <p className="mt-6 text-center text-sm text-emerald-400">If an account exists for {email}, a reset link is on its way.</p>
        ) : (
          <form className="mt-5 space-y-3" onSubmit={submit}>
            <Field icon={Mail} type="email" placeholder="you@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
            <button disabled={busy} className={goldBtn}>{busy ? 'Sending…' : 'Send reset link'} <ArrowRight className="h-4 w-4" /></button>
          </form>
        )}
        <p className="mt-6 text-center text-sm text-[#8a8577]"><Link to="/login" className="text-[#d4af37] hover:underline">Back to login</Link></p>
      </div>
    </Shell>
  );
}

const Group = ({ title, options, value, onChange }) => (
  <div>
    <p className="mb-2 text-sm font-medium text-[#c9c4b4]">{title}</p>
    <div className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button key={o} type="button" onClick={() => onChange(o)} className={`min-h-[44px] rounded-lg border px-3.5 py-2 text-sm transition ${value === o ? 'border-[#d4af37] bg-[#d4af37]/12 text-[#f0ecdd]' : 'border-[#d4af37]/15 text-[#8a8577] hover:border-[#d4af37]/40'}`}>{o}</button>
      ))}
    </div>
  </div>
);

export function OnboardingPage() {
  const nav = useNavigate();
  const { updateProfile } = useAuth();
  const [market, setMarket] = useState('Forex');
  const [exp, setExp] = useState('Intermediate');
  const [goal, setGoal] = useState('Discipline');
  const [busy, setBusy] = useState(false);

  const finish = async () => {
    setBusy(true);
    try { await updateProfile({ primaryMarket: market, experience: exp, goal }); } catch { /* non-blocking */ }
    setBusy(false);
    nav('/app/brokers');
  };

  return (
    <Shell>
      <div className="glass rounded-2xl p-6 sm:p-7">
        <h1 className="text-2xl font-bold">Tailor your terminal</h1>
        <p className="mt-1 text-sm text-[#8a8577]">Three quick questions. Your trial starts now.</p>
        <div className="mt-6 space-y-6">
          <Group title="Primary market" options={MARKETS} value={market} onChange={setMarket} />
          <Group title="Experience level" options={EXPERIENCE} value={exp} onChange={setExp} />
          <Group title="Main goal" options={GOALS} value={goal} onChange={setGoal} />
        </div>
        <button onClick={finish} disabled={busy} className={`${goldBtn} mt-8`}>Connect your brokers <ArrowRight className="h-4 w-4" /></button>
      </div>
    </Shell>
  );
}
